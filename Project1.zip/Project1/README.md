# Simple Network Topology (Cisco Packet Tracer)

## 📌 Overview
A simple network design created using **Cisco Packet Tracer** to demonstrate VLAN segmentation and Inter-VLAN routing.

---

## 📐 Topology & Components
The network consists of:
* **Router:** Configured for Inter-VLAN Routing (Router-on-a-Stick).
* **Switch:** Configured with 3 VLANs.
* **Devices:**
  * **VLAN 10:** Client Network 1.
  * **VLAN 20:** Client Network 2.
  * **VLAN 30:** Dedicated DNS Server.
  

---

## ⚙️ Network Configuration

| VLAN ID | Description | Subnet | Default Gateway |
| :--- | :--- | :--- | :--- |
| **VLAN 10** | Network 1 | `192.168.10.0/24` | `192.168.10.1` |
| **VLAN 20** | Network 2 | `192.168.20.0/24` | `192.168.20.1` |
| **VLAN 30** | DNS Server| `192.168.30.0/24` | `192.168.30.1` |

---

## 🚀 Key Implementation Steps
1. Created VLANs 10, 20, and 30 on the switch and assigned access ports.
2. Configured the trunk link between the switch and the router.
3. Configured sub-interfaces on the router for Inter-VLAN Routing.
4. Set up the DNS server and verified full connectivity across all VLANs via `ping` and domain resolution.

---

## 🛠️ Tools Used
* **Cisco Packet Tracer**